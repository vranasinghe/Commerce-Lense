
USE olist_dw;
GO

DROP TABLE IF EXISTS dbo.bronze_landing_holidays;

CREATE TABLE dbo.bronze_landing_holidays (
    raw_json NVARCHAR(MAX)
);

USE olist_dw;
GO

DROP TABLE IF EXISTS dbo.bronze_landing_usd_brl_rates;

CREATE TABLE dbo.bronze_landing_usd_brl_rates (
raw_json NVARCHAR(MAX)
);